export type ShareNetwork =
  | "x"
  | "linkedin"
  | "facebook"
  | "whatsapp";

export function getCurrentUrl() {
  if (typeof window === "undefined") return "";
  return window.location.href;
}

export function shareUrl(title: string, network: ShareNetwork) {
  const url = encodeURIComponent(getCurrentUrl());
  const text = encodeURIComponent(title);

  const urls: Record<ShareNetwork, string> = {
    x: `https://twitter.com/intent/tweet?url=${url}&text=${text}`,

    linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${url}`,

    facebook: `https://www.facebook.com/sharer/sharer.php?u=${url}`,

    whatsapp: `https://wa.me/?text=${text}%20${url}`,
  };

  window.open(
    urls[network],
    "_blank",
    "noopener,noreferrer,width=650,height=700"
  );
}

export async function copyCurrentUrl() {
  await navigator.clipboard.writeText(getCurrentUrl());
}

export async function nativeShare(title: string) {
  if (!("share" in navigator)) return false;

  try {
    await navigator.share({
      title,
      url: getCurrentUrl(),
    });

    return true;
  } catch {
    return false;
  }
}