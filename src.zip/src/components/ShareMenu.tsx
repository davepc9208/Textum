import {
  Check,
  Facebook,
  Link2,
  Linkedin,
  MessageCircle,
} from "lucide-react";
import { FaXTwitter } from "react-icons/fa6";
import { copyCurrentUrl, shareUrl } from "../utils/share";
import { useState } from "react";

type Props = {
  title: string;
  onClose?: () => void;
};

export default function ShareMenu({
  title,
  onClose,
}: Props) {
  const [copied, setCopied] = useState(false);

  async function handleCopy() {
    await copyCurrentUrl();

    setCopied(true);

    setTimeout(() => {
      setCopied(false);
    }, 2000);
  }

  const itemClass =
    "flex items-center gap-3 rounded-lg px-3 py-3 text-sm text-navy/70 transition-all duration-200 hover:bg-gold/10 hover:text-gold";

  return (
    <div
      className="
        w-72
        rounded-2xl
        border
        border-navy/10
        bg-white
        p-2
        shadow-xl
        animate-in
        fade-in
        zoom-in-95
        duration-200
      "
    >
      <div className="px-3 pt-3 pb-2">
        <p className="font-serif text-lg text-navy">
          Compartir artículo
        </p>

        <p className="text-xs text-navy/45 mt-1">
          Elige dónde quieres compartirlo.
        </p>
      </div>

      <div className="my-2 h-px bg-navy/10" />

      <button
        onClick={() => {
          shareUrl(title, "x");
          onClose?.();
        }}
        className={itemClass}
      >
        <FaXTwitter size={16} />
        <span>Compartir en X</span>
      </button>

      <button
        onClick={() => {
          shareUrl(title, "linkedin");
          onClose?.();
        }}
        className={itemClass}
      >
        <Linkedin size={17} />
        <span>LinkedIn</span>
      </button>

      <button
        onClick={() => {
          shareUrl(title, "facebook");
          onClose?.();
        }}
        className={itemClass}
      >
        <Facebook size={17} />
        <span>Facebook</span>
      </button>

      <button
        onClick={() => {
          shareUrl(title, "whatsapp");
          onClose?.();
        }}
        className={itemClass}
      >
        <MessageCircle size={17} />
        <span>WhatsApp</span>
      </button>

      <div className="my-2 h-px bg-navy/10" />

      <button
        onClick={handleCopy}
        className={itemClass}
      >
        {copied ? (
          <Check
            size={17}
            className="text-green-600"
          />
        ) : (
          <Link2 size={17} />
        )}

        <span>
          {copied
            ? "Enlace copiado"
            : "Copiar enlace"}
        </span>
      </button>
    </div>
  );
}