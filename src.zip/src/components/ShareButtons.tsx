import {
  Share2,
  Link2,
  Facebook,
  Linkedin,
  MessageCircle,
  Check,
} from "lucide-react";
import { FaXTwitter } from "react-icons/fa6";
import {
  useEffect,
  useRef,
  useState,
} from "react";

type Props = {
  title: string;
  variant?: "compact" | "full";
};

export default function ShareButtons({
  title,
  variant = "compact",
}: Props) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const ref = useRef<HTMLDivElement>(null);

  const url =
    typeof window !== "undefined"
      ? window.location.href
      : "";

  const encodedUrl = encodeURIComponent(url);
  const encodedTitle = encodeURIComponent(title);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (
        ref.current &&
        !ref.current.contains(e.target as Node)
      ) {
        setOpen(false);
      }
    };

    document.addEventListener(
      "mousedown",
      handler
    );

    return () =>
      document.removeEventListener(
        "mousedown",
        handler
      );
  }, []);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
      }
    };

    window.addEventListener(
      "keydown",
      handler
    );

    return () =>
      window.removeEventListener(
        "keydown",
        handler
      );
  }, []);

  async function copyLink() {
    await navigator.clipboard.writeText(url);

    setCopied(true);

    setTimeout(() => {
      setCopied(false);
    }, 2000);
  }

  async function nativeShare() {
    if (navigator.share) {
      try {
        await navigator.share({
          title,
          url,
        });

        return true;
      } catch {
        return false;
      }
    }

    return false;
  }

  function toggleMenu() {
    if (navigator.share && window.innerWidth < 768) {
      nativeShare();
      return;
    }

    setOpen((v) => !v);
  }

  const menu = (
    <div className="absolute right-0 mt-3 w-60 rounded-xl border border-navy/10 bg-white shadow-xl overflow-hidden z-50">

      <a
        href={`https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedTitle}`}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-3 px-4 py-3 hover:bg-gold/10 transition-colors"
      >
        <FaXTwitter size={16} />
        <span>Compartir en X</span>
      </a>

      <a
        href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-3 px-4 py-3 hover:bg-gold/10 transition-colors"
      >
        <Linkedin size={16} />
        <span>LinkedIn</span>
      </a>

      <a
        href={`https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-3 px-4 py-3 hover:bg-gold/10 transition-colors"
      >
        <Facebook size={16} />
        <span>Facebook</span>
      </a>

      <a
        href={`https://wa.me/?text=${encodedTitle}%20${encodedUrl}`}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-3 px-4 py-3 hover:bg-gold/10 transition-colors"
      >
        <MessageCircle size={16} />
        <span>WhatsApp</span>
      </a>

      <button
        onClick={copyLink}
        className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gold/10 transition-colors text-left"
      >
        {copied ? (
          <Check size={16} />
        ) : (
          <Link2 size={16} />
        )}

        <span>
          {copied
            ? "Enlace copiado"
            : "Copiar enlace"}
        </span>
      </button>

    </div>
  );

  if (variant === "compact") {
    return (
      <div
        ref={ref}
        className="relative"
      >
        <button
          onClick={toggleMenu}
          className="inline-flex items-center gap-2 rounded-full border border-navy/10 bg-white px-4 py-2 text-sm text-navy/70 shadow-sm hover:border-gold/40 hover:text-gold transition-all"
        >
          <Share2 size={16} />
          Compartir
        </button>

        {open && menu}
      </div>
    );
  }

  return (
    <div
      ref={ref}
      className="relative mt-16 rounded-2xl border border-navy/10 bg-white p-8 text-center shadow-sm"
    >
      <h3 className="font-serif text-2xl text-navy mb-3">
        Comparte este artículo
      </h3>

      <p className="text-navy/60 mb-6">
        Si te ha resultado útil,
        ayúdanos a que llegue a más personas.
      </p>

      <button
        onClick={toggleMenu}
        className="inline-flex items-center gap-2 rounded-full bg-gold px-6 py-3 text-navy font-medium hover:opacity-90 transition"
      >
        <Share2 size={18} />
        Compartir
      </button>

      {open && (
        <div className="flex flex-col gap-2 mt-6">
          {menu}
        </div>
      )}
    </div>
  );
}